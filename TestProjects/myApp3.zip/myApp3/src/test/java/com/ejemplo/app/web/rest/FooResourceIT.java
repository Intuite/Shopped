package com.ejemplo.app.web.rest;

import com.ejemplo.app.MyApp3App;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
/**
 * Test class for the FooResource REST controller.
 *
 * @see FooResource
 */
@SpringBootTest(classes = MyApp3App.class)
public class FooResourceIT {

    private MockMvc restMockMvc;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        FooResource fooResource = new FooResource();
        restMockMvc = MockMvcBuilders
            .standaloneSetup(fooResource)
            .build();
    }

    /**
     * Test prueba
     */
    @Test
    public void testPrueba() throws Exception {
        restMockMvc.perform(post("/api/foo/prueba"))
            .andExpect(status().isOk());
    }

    /**
     * Test prueba1
     */
    @Test
    public void testPrueba1() throws Exception {
        restMockMvc.perform(get("/api/foo/prueba-1"))
            .andExpect(status().isOk());
    }
}
