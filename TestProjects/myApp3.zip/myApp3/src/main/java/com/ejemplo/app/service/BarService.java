package com.ejemplo.app.service;

public interface BarService {

}
