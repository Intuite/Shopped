/**
 * Spring MVC REST controllers.
 */
package com.ejemplo.app.web.rest;
