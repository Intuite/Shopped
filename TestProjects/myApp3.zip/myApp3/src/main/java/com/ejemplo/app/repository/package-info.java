/**
 * Spring Data JPA repositories.
 */
package com.ejemplo.app.repository;
