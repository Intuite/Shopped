package com.ejemplo.app.web.rest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * FooResource controller
 */
@RestController
@RequestMapping("/api/foo")
public class FooResource {

    private final Logger log = LoggerFactory.getLogger(FooResource.class);

    /**
    * POST prueba
    */
    @PostMapping("/prueba")
    public String prueba() {
        return "prueba";
    }

    /**
    * GET prueba1
    */
    @GetMapping("/prueba-1")
    public String prueba1() {
        return "prueba1";
    }

}
