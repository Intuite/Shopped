/**
 * Service layer beans.
 */
package com.ejemplo.app.service;
