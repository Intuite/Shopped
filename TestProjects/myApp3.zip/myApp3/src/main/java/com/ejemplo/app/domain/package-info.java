/**
 * JPA domain objects.
 */
package com.ejemplo.app.domain;
