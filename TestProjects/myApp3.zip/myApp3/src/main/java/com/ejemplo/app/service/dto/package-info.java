/**
 * Data Transfer Objects.
 */
package com.ejemplo.app.service.dto;
