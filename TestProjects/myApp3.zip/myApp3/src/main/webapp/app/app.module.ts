import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import './vendor';
import { MyApp3SharedModule } from 'app/shared/shared.module';
import { MyApp3CoreModule } from 'app/core/core.module';
import { MyApp3AppRoutingModule } from './app-routing.module';
import { MyApp3HomeModule } from './home/home.module';
import { MyApp3EntityModule } from './entities/entity.module';
// jhipster-needle-angular-add-module-import JHipster will add new module here
import { MainComponent } from './layouts/main/main.component';
import { NavbarComponent } from './layouts/navbar/navbar.component';
import { FooterComponent } from './layouts/footer/footer.component';
import { PageRibbonComponent } from './layouts/profiles/page-ribbon.component';
import { ActiveMenuDirective } from './layouts/navbar/active-menu.directive';
import { ErrorComponent } from './layouts/error/error.component';
import { Component1Component } from './components/component1/component1.component';
import { Component2Component } from './components/component2/component2.component';

@NgModule({
  imports: [
    BrowserModule,
    MyApp3SharedModule,
    MyApp3CoreModule,
    MyApp3HomeModule,
    // jhipster-needle-angular-add-module JHipster will add new module here
    MyApp3EntityModule,
    MyApp3AppRoutingModule,
  ],
  declarations: [MainComponent, NavbarComponent, ErrorComponent, PageRibbonComponent, ActiveMenuDirective, FooterComponent, Component1Component, Component2Component],
  bootstrap: [MainComponent],
})
export class MyApp3AppModule {}
