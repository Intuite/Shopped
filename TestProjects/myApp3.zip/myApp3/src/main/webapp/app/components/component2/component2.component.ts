import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'jhi-component2',
  templateUrl: './component2.component.html',
  styleUrls: ['./component2.component.scss']
})
export class Component2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
